

CREATE DATABASE IF NOT EXISTS RiskHOP;
USE RiskHOP;

-- 1. ADMIN USERS TABLE
CREATE TABLE mg6_admin_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. RISKHOP MATRIX (Main Game Configuration)
CREATE TABLE mg6_riskhop_matrix (
    id INT PRIMARY KEY AUTO_INCREMENT,
    game_name VARCHAR(200) NOT NULL,
    description TEXT,
    risk_capital INT(3) NOT NULL,
    dice_limit INT(2) NOT NULL,
    matrix_type ENUM('6x6', '8x8', '10x10', '12x12') NOT NULL,
    total_cells INT NOT NULL,
    status ENUM('draft', 'published', 'archived') DEFAULT 'draft',
    created_by INT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    published_date TIMESTAMP NULL,
    FOREIGN KEY (created_by) REFERENCES mg6_admin_users(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_created_by (created_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. THREATS (Snakes)
CREATE TABLE mg6_riskhop_threats (
    id INT PRIMARY KEY AUTO_INCREMENT,
    matrix_id INT NOT NULL,
    threat_name VARCHAR(200) NOT NULL,
    threat_description TEXT,
    cell_from INT NOT NULL,
    cell_to INT NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (matrix_id) REFERENCES mg6_riskhop_matrix(id) ON DELETE CASCADE,
    INDEX idx_matrix (matrix_id),
    INDEX idx_cells (cell_from, cell_to)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. OPPORTUNITIES (Ladders)
CREATE TABLE mg6_riskhop_opportunities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    matrix_id INT NOT NULL,
    opportunity_name VARCHAR(200) NOT NULL,
    opportunity_description TEXT,
    cell_from INT NOT NULL,
    cell_to INT NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (matrix_id) REFERENCES mg6_riskhop_matrix(id) ON DELETE CASCADE,
    INDEX idx_matrix (matrix_id),
    INDEX idx_cells (cell_from, cell_to)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. STRATEGIES (Risk Responses)
CREATE TABLE mg6_riskhop_strategies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    strategy_name VARCHAR(200) NOT NULL,
    description TEXT,
    response_points INT(3) NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (strategy_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. THREAT-STRATEGY MAPPING
CREATE TABLE mg6_threat_strategy_mapping (
    id INT PRIMARY KEY AUTO_INCREMENT,
    threat_id INT NOT NULL,
    strategy_id INT NOT NULL,
    FOREIGN KEY (threat_id) REFERENCES mg6_riskhop_threats(id) ON DELETE CASCADE,
    FOREIGN KEY (strategy_id) REFERENCES mg6_riskhop_strategies(id) ON DELETE CASCADE,
    UNIQUE KEY unique_mapping (threat_id, strategy_id),
    INDEX idx_threat (threat_id),
    INDEX idx_strategy (strategy_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. OPPORTUNITY-STRATEGY MAPPING
CREATE TABLE mg6_opportunity_strategy_mapping (
    id INT PRIMARY KEY AUTO_INCREMENT,
    opportunity_id INT NOT NULL,
    strategy_id INT NOT NULL,
    FOREIGN KEY (opportunity_id) REFERENCES mg6_riskhop_opportunities(id) ON DELETE CASCADE,
    FOREIGN KEY (strategy_id) REFERENCES mg6_riskhop_strategies(id) ON DELETE CASCADE,
    UNIQUE KEY unique_mapping (opportunity_id, strategy_id),
    INDEX idx_opportunity (opportunity_id),
    INDEX idx_strategy (strategy_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. BONUS CELLS
CREATE TABLE mg6_riskhop_bonus (
    id INT PRIMARY KEY AUTO_INCREMENT,
    matrix_id INT NOT NULL,
    cell_number INT NOT NULL,
    bonus_amount INT NOT NULL,
    FOREIGN KEY (matrix_id) REFERENCES mg6_riskhop_matrix(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cell (matrix_id, cell_number),
    INDEX idx_matrix (matrix_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. AUDIT CELLS
CREATE TABLE mg6_riskhop_audit (
    id INT PRIMARY KEY AUTO_INCREMENT,
    matrix_id INT NOT NULL,
    cell_number INT NOT NULL,
    FOREIGN KEY (matrix_id) REFERENCES mg6_riskhop_matrix(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cell (matrix_id, cell_number),
    INDEX idx_matrix (matrix_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. WILDCARD CELLS (Which cells have wildcards)
CREATE TABLE mg6_riskhop_wildcard_cells (
    id INT PRIMARY KEY AUTO_INCREMENT,
    matrix_id INT NOT NULL,
    cell_number INT NOT NULL,
    FOREIGN KEY (matrix_id) REFERENCES mg6_riskhop_matrix(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cell (matrix_id, cell_number),
    INDEX idx_matrix (matrix_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. WILDCARDS (Wildcard options)
CREATE TABLE mg6_riskhop_wildcards (
    id INT PRIMARY KEY AUTO_INCREMENT,
    matrix_id INT NOT NULL,
    wildcard_name VARCHAR(200) NOT NULL,
    wildcard_description TEXT,
    wildcard_image VARCHAR(255),
    risk_capital_effect INT DEFAULT 0,
    dice_effect INT DEFAULT 0,
    cell_effect INT DEFAULT 0,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (matrix_id) REFERENCES mg6_riskhop_matrix(id) ON DELETE CASCADE,
    INDEX idx_matrix (matrix_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. GAME SESSIONS (Player game tracking)
CREATE TABLE mg6_game_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    matrix_id INT NOT NULL,
    player_name VARCHAR(100),
    current_cell INT DEFAULT 1,
    dice_remaining INT NOT NULL,
    capital_remaining INT NOT NULL,
    game_status ENUM('playing', 'completed', 'abandoned') DEFAULT 'playing',
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP NULL,
    FOREIGN KEY (matrix_id) REFERENCES mg6_riskhop_matrix(id) ON DELETE CASCADE,
    INDEX idx_matrix (matrix_id),
    INDEX idx_status (game_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12.5 SESSION WILDCARDS (Opened wildcards per session)
CREATE TABLE mg6_session_wildcards_opened (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    wildcard_id INT NOT NULL,
    opened_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES mg6_game_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (wildcard_id) REFERENCES mg6_riskhop_wildcards(id) ON DELETE CASCADE,
    UNIQUE KEY unique_wildcard_session (session_id, wildcard_id),
    INDEX idx_session (session_id),
    INDEX idx_wildcard (wildcard_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. PLAYER INVESTMENTS (Strategy investments)
CREATE TABLE mg6_player_investments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    strategy_id INT NOT NULL,
    investment_points INT NOT NULL,
    invested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES mg6_game_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (strategy_id) REFERENCES mg6_riskhop_strategies(id) ON DELETE CASCADE,
    INDEX idx_session (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. GAME MOVES (Game history tracking)
CREATE TABLE mg6_game_moves (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    move_number INT NOT NULL,
    dice_value INT NOT NULL,
    from_cell INT NOT NULL,
    to_cell INT NOT NULL,
    event_type ENUM('normal', 'snake', 'ladder', 'bonus', 'audit', 'wildcard') DEFAULT 'normal',
    event_description TEXT,
    move_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES mg6_game_sessions(id) ON DELETE CASCADE,
    INDEX idx_session (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 15. GAME STATISTICS (Final game results)
CREATE TABLE mg6_game_statistics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    max_cell_reached INT NOT NULL,
    total_dice_used INT NOT NULL,
    threats_protected INT DEFAULT 0,
    threats_total INT DEFAULT 0,
    opportunities_exploited INT DEFAULT 0,
    opportunities_total INT DEFAULT 0,
    wildcards_opened INT DEFAULT 0,
    final_capital INT DEFAULT 0,
    game_score INT DEFAULT 0,
    FOREIGN KEY (session_id) REFERENCES mg6_game_sessions(id) ON DELETE CASCADE,
    UNIQUE KEY unique_session (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO mg6_admin_users (username, email, password) VALUES 
('admin', 'admin@riskhop.com', MD5('admin123'));



-- Sample Game Matrix
INSERT INTO mg6_riskhop_matrix (game_name, description, risk_capital, dice_limit, matrix_type, total_cells, status, created_by) VALUES 
('Cyber Security Challenge', 'Learn cybersecurity risk management through gameplay', 100, 15, '8x8', 64, 'published', 1);

-- Sample Threat
INSERT INTO mg6_riskhop_threats (matrix_id, threat_name, threat_description, cell_from, cell_to) VALUES 
(1, 'Phishing Attack', 'Employee clicks malicious email link', 45, 12);

-- Sample Opportunity
INSERT INTO mg6_riskhop_opportunities (matrix_id, opportunity_name, opportunity_description, cell_from, cell_to) VALUES 
(1, 'Security Certification', 'Team completed ISO 27001 certification', 15, 42);

-- Sample Strategies
INSERT INTO mg6_riskhop_strategies (strategy_name, description, response_points) VALUES 
('Email Filtering', 'Advanced spam and phishing detection', 10),
('Security Awareness Training', 'Employee cybersecurity education program', 8),
('Multi-Factor Authentication', 'Two-factor authentication implementation', 15);

-- Sample Threat-Strategy Mapping
INSERT INTO mg6_threat_strategy_mapping (threat_id, strategy_id) VALUES 
(1, 1),
(1, 2),
(1, 3);

-- Sample Bonus Cell
INSERT INTO mg6_riskhop_bonus (matrix_id, cell_number, bonus_amount) VALUES 
(1, 28, 25);

-- Sample Audit Cell
INSERT INTO mg6_riskhop_audit (matrix_id, cell_number) VALUES 
(1, 35);

-- Sample Wildcard Cell
INSERT INTO mg6_riskhop_wildcard_cells (matrix_id, cell_number) VALUES 
(1, 19);

-- Sample Wildcards
INSERT INTO mg6_riskhop_wildcards (matrix_id, wildcard_name, wildcard_description, wildcard_image, risk_capital_effect, dice_effect, cell_effect) VALUES 
(1, 'Emergency Budget Approval', 'CFO approved additional security budget', 'budget_approval.png', 50, 0, 0),
(1, 'Budget Cut', 'Quarterly budget reduced', 'budget_cut.png', -30, -2, 0),
(1, 'Fast Track Initiative', 'Skip ahead with executive sponsorship', 'fast_track.png', 0, 0, 10),
(1, 'Compliance Violation', 'Failed audit, penalties applied', 'violation.png', -20, -1, -5);